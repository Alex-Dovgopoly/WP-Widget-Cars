<?php

add_action('add_meta_boxes', 'myplugin_add_custom_box');
function myplugin_add_custom_box(){
	add_meta_box( 'myplugin_section_car_spec', 'Характеристики авто', 'myplugin_meta_box_spec', 'cars' );
}

// HTML код блока
function myplugin_meta_box_spec($cars)
{
    $engine = get_post_meta($cars->ID, 'Тип двигателя', true);
	$body = get_post_meta($cars->ID, 'Тип кузова', true);
	$door = get_post_meta($cars->ID, 'Кол-во дверей', true);
	$year = get_post_meta($cars->ID, 'Год выпуска', true);

    ?>
    <p><label for="engine_field">Тип двигателя</label>
    <select name="engine_field" id="engine_field" class="postbox">
		<option selected disabled>Выбрать тип двигателя!</option>
        <option value="Бензин" <?php selected($engine, 'Бензин'); ?>>Бензин</option>
        <option value="Дизель" <?php selected($engine, 'Дизель'); ?>>Дизель</option>
		<option value="Электро" <?php selected($engine, 'Электро'); ?>>Электро</option>
    </select></p>

	<p><label for="body_field">Тип кузова</label>
    <select name="body_field" id="body_field" class="postbox">
        <option selected disabled>Выбрать тип кузова</option>
		<option value="Седан" <?php selected($body, 'Седан'); ?>>Седан</option>
        <option value="Хетчбэк" <?php selected($body, 'Хетчбэк'); ?>>Хетчбэк</option>
		<option value="Универсал" <?php selected($body, 'Универсал'); ?>>Универсал</option>
		<option value="Кросовер" <?php selected($body, 'Кросовер'); ?>>Кросовер</option>
		<option value="SUV" <?php selected($body, 'SUV'); ?>>SUV</option>
		<option value="Купэ" <?php selected($body, 'Купэ'); ?>>Купэ</option>
		<option value="Кабриолет" <?php selected($body, 'Кабриолет'); ?>>Кабриолет</option>
		<option value="Родстер" <?php selected($body, 'Родстер'); ?>>Родстер</option>
    </select></p>

	<p><label for="door_field">Кол-во дверей</label>
    <select name="door_field" id="door_field" class="postbox">
        <option selected disabled>Выбрать кол-во дверей</option>
		<option value="2" <?php selected($door, '2'); ?>>2</option>
		<option value="3" <?php selected($door, '3'); ?>>3</option>
        <option value="4" <?php selected($door, '4'); ?>>4</option>
		<option value="5" <?php selected($door, '5'); ?>>5</option>
    </select></p>

	<p><label for="year_field">Год выпуска</label>
	<input type="number" name="year_field" id="year_field" value="<?php echo $year ?>">
	</p>
    <?php
}

## Сохраняем данные, когда пост сохраняется
add_action('save_post', 'myplugin_save_postdata');
function myplugin_save_postdata($cars_id)
{
    if (array_key_exists('engine_field', $_POST)) {
        update_post_meta( $cars_id, 'Тип двигателя', $_POST['engine_field'] );
		update_post_meta( $cars_id, 'Тип кузова', $_POST['body_field'] );
		update_post_meta( $cars_id, 'Кол-во дверей', $_POST['door_field'] );
		update_post_meta( $cars_id, 'Год выпуска', $_POST['year_field'] );
    }
}