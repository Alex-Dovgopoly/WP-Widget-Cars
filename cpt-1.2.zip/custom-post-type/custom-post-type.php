<?php

/**
 * Plugin Name:       Custom post type
 * Description:       Create custom post type and add some widget
 * Version:           1.0.0
 * Author:            Sanya Digital
 */


/**
 * Регистрируем новый тип поста и активируем плагин
 */
add_action( 'init', 'myplugin_setup_post_types' );
function myplugin_setup_post_types(){
	// Регистрируем тип записи "cars"
	register_post_type('cars', array(
		'label'  => null,
		'labels' => array(
			'name'               => 'Все авто', // основное название для типа записи
			'singular_name'      => 'Автомобиль', // название для одной записи этого типа
			'add_new'            => 'Добавить новый', // для добавления новой записи
			'add_new_item'       => 'Добавление авто', // заголовка у вновь создаваемой записи в админ-панели.
			'edit_item'          => 'Редактировать авто', // для редактирования типа записи
			'new_item'           => 'Новое авто', // текст новой записи
			'view_item'          => 'Просмотреть', // для просмотра записи этого типа.
			'search_items'       => 'Search car', // для поиска по этим типам записи
			'not_found'          => 'Car not found', // если в результате поиска ничего не было найдено
			'not_found_in_trash' => 'Not found in trash', // если не было найдено в корзине
			'menu_name'          => 'Автомобили', // название меню
		),
		'description'         => '',
		'menu_position'       => 5,
		'menu_icon'			  => 'dashicons-dashboard',
		'supports'            => [ 'title', 'editor', 'thumbnail' ],
		'public'              => true,
	) );
}

register_activation_hook( __FILE__, 'myplugin_install' );
function myplugin_install(){
	// Запускаем функцию регистрации типа записи
	myplugin_setup_post_types();

	// Сбрасываем настройки ЧПУ, чтобы они пересоздались с новыми данными
	flush_rewrite_rules();

	// Загружаем демо-контент
	upload_demo_content();
}

/**
/ Функция загрузки демо записей
*/
function upload_demo_content() {
	require_once plugin_dir_path( __FILE__ ) . '/includes/demo/upload-post-1.php';
	require_once plugin_dir_path( __FILE__ ) . '/includes/demo/upload-post-2.php';
	require_once plugin_dir_path( __FILE__ ) . '/includes/demo/upload-post-3.php';
	require_once plugin_dir_path( __FILE__ ) . '/includes/demo/upload-post-4.php';
	require_once plugin_dir_path( __FILE__ ) . '/includes/demo/upload-post-5.php';
}

/**
/ Подключаем widget-cars
*/
require_once plugin_dir_path( __FILE__ ) . '/widget/widgets.php';
require_once plugin_dir_path( __FILE__ ) . '/widget/widget-cars.php';

/**
/ Меняем плейсхолдер заголовков для постов типа cars
*/
add_filter( 'enter_title_here', 'custom_enter_title' );
function custom_enter_title( $input ) {
    if ( 'cars' === get_post_type() ) {
        return __( 'Марка и модель', 'your_textdomain' );
    }

    return $input;
}


/**
 * Создаем доп. поля кастомного поста
 */

require_once plugin_dir_path( __FILE__ ) . '/includes/custom-meta-boxes.php';


/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-plugin-name-deactivator.php
*/
function deactivate_plugin_name() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-plugin-name-deactivator.php';
	Plugin_Name_Deactivator::deactivate();
}

register_deactivation_hook( __FILE__, 'deactivate_plugin_name' );