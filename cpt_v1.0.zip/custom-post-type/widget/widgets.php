<?php

// register Cars_Widget widget
function register_cars_widget() {
    register_widget( 'Cars_Widget' );
}
add_action( 'widgets_init', 'register_cars_widget' );