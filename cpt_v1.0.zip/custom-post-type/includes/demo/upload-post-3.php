<?php

require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-admin/includes/admin.php' );

$car_data = array(
    'post_title'    => 'Tesla Model 3',
    'post_content'  => 'Content of the test post with an additional field',
	'post_type'     => 'cars',
    'post_status'   => 'publish',
    'post_author'   => 1,
    'post_category' => array(1)
);

// Create a post with required fields.
$cars_id = wp_insert_post($car_data, true);

// Add the post-meta
update_post_meta($cars_id , 'engine_meta_key', 'electic');
update_post_meta($cars_id , 'body_meta_key', 'sedan');
update_post_meta($cars_id , 'door_meta_key', 'four');
update_post_meta($cars_id , 'year_meta_key', '2018');

// For example, take a picture from my blog

$url = 'http://plugin.sixsenses.store/wp-content/uploads/2020/02/tesla.jpg';

// We will add it as the cover to the current post

$description = "Tesla 3";
$file_array = array();
$tmp = download_url($url);

preg_match('/[^\?]+\.(jpg|jpe|jpeg|gif|png)/i', $url, $matches );
$file_array['name'] = basename($matches[0]);
$file_array['tmp_name'] = $tmp;

$media_id = media_handle_sideload($file_array, $cars_id, $description);

if (is_wp_error($media_id)) {
    @unlink($file_array['tmp_name']);
    echo $media_id->get_error_messages();
}

@unlink($file_array['tmp_name'] );

set_post_thumbnail($cars_id, $media_id);