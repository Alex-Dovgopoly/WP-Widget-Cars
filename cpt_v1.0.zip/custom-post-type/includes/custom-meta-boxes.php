<?php

add_action('add_meta_boxes', 'myplugin_add_custom_box');
function myplugin_add_custom_box(){
	add_meta_box( 'myplugin_section_car_spec', 'Характеристики авто', 'myplugin_meta_box_spec', 'cars' );
}

// HTML код блока
function myplugin_meta_box_spec($cars)
{
    $engine = get_post_meta($cars->ID, 'engine_meta_key', true);
	$body = get_post_meta($cars->ID, 'body_meta_key', true);
	$door = get_post_meta($cars->ID, 'door_meta_key', true);
	$year = get_post_meta($cars->ID, 'year_meta_key', true);

    ?>
    <p><label for="engine_field">Тип двигателя</label>
    <select name="engine_field" id="engine_field" class="postbox">
		<option selected disabled>Выбрать тип двигателя!</option>
        <option value="petrol" <?php selected($engine, 'petrol'); ?>>Бензин</option>
        <option value="diesel" <?php selected($engine, 'diesel'); ?>>Дизель</option>
		<option value="electic" <?php selected($engine, 'electic'); ?>>Электро</option>
    </select></p>

	<p><label for="body_field">Тип кузова</label>
    <select name="body_field" id="body_field" class="postbox">
        <option selected disabled>Выбрать тип кузова</option>
		<option value="sedan" <?php selected($body, 'sedan'); ?>>Седан</option>
        <option value="hatch" <?php selected($body, 'hatch'); ?>>Хетчбэк</option>
		<option value="universal" <?php selected($body, 'universal'); ?>>Универсал</option>
		<option value="kros" <?php selected($body, 'kros'); ?>>Кросовер</option>
		<option value="suv" <?php selected($body, 'suv'); ?>>SUV</option>
		<option value="coup" <?php selected($body, 'coup'); ?>>Купэ</option>
		<option value="cabrio" <?php selected($body, 'cabrio'); ?>>Кабриолет</option>
		<option value="roadster" <?php selected($body, 'roadster'); ?>>Родстер</option>
    </select></p>

	<p><label for="door_field">Кол-во дверей</label>
    <select name="door_field" id="door_field" class="postbox">
        <option selected disabled>Выбрать кол-во дверей</option>
		<option value="two" <?php selected($door, 'two'); ?>>2</option>
		<option value="tri" <?php selected($door, 'tri'); ?>>3</option>
        <option value="four" <?php selected($door, 'four'); ?>>4</option>
		<option value="five" <?php selected($door, 'five'); ?>>5</option>
    </select></p>

	<p><label for="year_field">Год выпуска</label>
	<input type="number" name="year_field" id="year_field" value="<?php echo $year ?>">
	</p>
    <?php
}

## Сохраняем данные, когда пост сохраняется
add_action('save_post', 'myplugin_save_postdata');
function myplugin_save_postdata($cars_id)
{
    if (array_key_exists('engine_field', $_POST)) {
        update_post_meta( $cars_id, 'engine_meta_key', $_POST['engine_field'] );
		update_post_meta( $cars_id, 'body_meta_key', $_POST['body_field'] );
		update_post_meta( $cars_id, 'door_meta_key', $_POST['door_field'] );
		update_post_meta( $cars_id, 'year_meta_key', $_POST['year_field'] );
    }
}